-- Claude Advisor: writes state + chat to script-output/claude-advisor/
-- Inbound path (bridge -> game) is RCON calling /claude_say.

local DIR = "claude-advisor/"
local SNAPSHOT_TICKS = 60 * 60 -- 1 game minute at 60 UPS

local ENTITY_TYPES = {
  "mining-drill", "furnace", "assembling-machine", "lab", "inserter",
  "transport-belt", "electric-pole", "solar-panel", "accumulator",
  "boiler", "generator", "reactor", "roboport", "ammo-turret",
  "electric-turret", "rocket-silo", "train-stop", "locomotive",
}

local ALERT_NAMES = {}
for k, v in pairs(defines.alert_type) do ALERT_NAMES[v] = k end

local function write(name, data, append)
  -- for_player = 0: write on the server (the host) only
  helpers.write_file(DIR .. name, data, append, 0)
end

local function snapshot()
  local force = game.forces.player
  local state = { tick = game.tick, surfaces = {}, players = {} }

  local r = force.current_research
  if r then state.research = { name = r.name, progress = force.research_progress } end

  local ok, queue = pcall(function()
    local t = {}
    for _, tech in pairs(force.research_queue) do t[#t + 1] = tech.name end
    return t
  end)
  if ok then state.research_queue = queue end

  for _, surface in pairs(game.surfaces) do
    local s = { entities = {} }
    local any = false
    for _, t in pairs(ENTITY_TYPES) do
      local n = surface.count_entities_filtered { force = force, type = t }
      if n > 0 then s.entities[t] = n; any = true end
    end
    if any then
      local okp, stats = pcall(function() return force.get_item_production_statistics(surface) end)
      if okp and stats then
        s.produced = stats.input_counts   -- all-time totals; bridge diffs them into rates
        s.consumed = stats.output_counts
      end
      local oke, evo = pcall(function() return game.forces.enemy.get_evolution_factor(surface) end)
      if oke then s.evolution = evo end
      state.surfaces[surface.name] = s
    end
  end

  for _, p in pairs(game.connected_players) do
    local pd = {
      name = p.name,
      surface = p.surface.name,
      position = { x = math.floor(p.position.x), y = math.floor(p.position.y) },
      alerts = {},
    }
    for _, by_type in pairs(p.get_alerts {}) do
      for atype, list in pairs(by_type) do
        local n = ALERT_NAMES[atype] or tostring(atype)
        pd.alerts[n] = (pd.alerts[n] or 0) + #list
      end
    end
    local inv = p.get_main_inventory()
    if inv then pd.inventory = inv.get_contents() end
    state.players[#state.players + 1] = pd
  end

  write("state.json", helpers.table_to_json(state), false)
end

-- Never let the advisor crash the game.
local function safe_snapshot()
  local ok, err = pcall(snapshot)
  if not ok then log("claude-advisor snapshot failed: " .. tostring(err)) end
end

script.on_init(function()
  write("chat.jsonl", "", false)
  safe_snapshot()
end)

script.on_nth_tick(SNAPSHOT_TICKS, safe_snapshot)

script.on_event(defines.events.on_console_chat, function(e)
  if not e.player_index then return end
  local p = game.get_player(e.player_index)
  if not p then return end
  local addressed = e.message:lower():sub(1, 7) == "@claude"
  if addressed then safe_snapshot() end -- fresh state lands before the question
  write("chat.jsonl", helpers.table_to_json {
    tick = game.tick, player = p.name, message = e.message, addressed = addressed,
  } .. "\n", true)
end)

commands.add_command("claude_say", "Print an advisor message (RCON/admin only).", function(cmd)
  if cmd.player_index then
    local p = game.get_player(cmd.player_index)
    if not (p and p.admin) then return end
  end
  if cmd.parameter and cmd.parameter ~= "" then
    game.print("[color=orange][Claude][/color] " .. cmd.parameter)
  end
end)

commands.add_command("claude_snapshot", "Force a state snapshot.", function() safe_snapshot() end)
